###########################################################
###     Read expected values of variables 		###
###    and print different kinds of spectra		###
###########################################################

import numpy as np
from matplotlib import pyplot as plt

au2fs=0.024188843341
au2ang=0.529177
rad2deg=180./np.pi

###########################################################
### Import data
### Note: the order of the data is: energy, intensity, time

filename='../expect.dat'

data=np.loadtxt(filename)

###########################################################
### Get number of times

ntimes=len(data)

print('\n ntimes =',ntimes)

###########################################################
### Separate data for plotting

time=np.zeros(ntimes)
R_avg=np.zeros(ntimes)
theta_avg=np.zeros(ntimes)
CN_avg=np.zeros(ntimes)
nlevel=2
for i in range(ntimes):
	time[i] = data[i,0]
	R_avg[i] = data[i,nlevel]
	theta_avg[i] = data[i,nlevel+3]
	CN_avg[i] = data[i,nlevel+6]

###########################################################
### Chance units

time=time*au2fs

R_avg=R_avg*au2ang
CN_avg=CN_avg*au2ang

theta_avg=theta_avg*rad2deg

theta_avg=theta_avg-theta_avg[0]

###########################################################
### Plot data

plt.rcParams['axes.linewidth'] = 1.5

fig1,ax1=plt.subplots()
fig2,ax2=plt.subplots()
fig3,ax3=plt.subplots()

#fig.subplots_adjust(bottom=0.12,right=1.0,top=0.92)

lw=2.

ax1.plot(time,R_avg,'-',lw=lw)
ax2.plot(time,theta_avg,'-',lw=lw)
ax3.plot(time,CN_avg,'-',lw=lw)

### set labels

sz=16

ax1.set_title('Expected value',size=sz)
ax2.set_title('Expected value',size=sz)
ax3.set_title('Expected value',size=sz)

sz = 16

ax1.set_xlabel(r'$\mathregular{t \ (fs)}$',size=sz)
ax2.set_xlabel(r'$\mathregular{t \ (fs)}$',size=sz)
ax3.set_xlabel(r'$\mathregular{t \ (fs)}$',size=sz)

ax1.set_ylabel(r'$\mathregular{<R_{I-CM}> \ (\AA)}$',size=sz)
ax2.set_ylabel(r'$\mathregular{<\theta_{I-CM-C}> \ (\degree)}$',size=sz)
ax3.set_ylabel(r'$\mathregular{<r_{CN}> \ (\AA)}$',size=sz,labelpad=-2)

### set axis limits

x_axis=[280,305]

y_axis=[0,3000]

#ax.set_xlim(x_axis)

#ax.set_ylim(y_axis)

### set axis ticks

#ax.set_xticks(np.arange(-180.,180.+45,45.))

ax3.set_yticks(np.arange(1.16,1.20,.01))

labelsz = 12
ax1.tick_params(axis='both',which='major',labelsize=labelsz)
ax2.tick_params(axis='both',which='major',labelsize=labelsz)
ax3.tick_params(axis='both',which='major',labelsize=labelsz)

### plot

plt.show()

###########################################################
### Save plot

fig1.savefig('R_avg.pdf',format='pdf',dpi=1200)
fig2.savefig('theta_avg.pdf',format='pdf',dpi=1200)
fig3.savefig('CN_avg.pdf',format='pdf',dpi=1200)

###########################################################
### End program

print('\n DONE!! \n')

