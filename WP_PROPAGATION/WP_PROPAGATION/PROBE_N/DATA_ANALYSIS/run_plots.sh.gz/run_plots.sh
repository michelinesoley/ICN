python plot_avg.py 
python plot_2D.py 
python plot_1D.py 
