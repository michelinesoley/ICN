#!/bin/bash
#SBATCH -o error.err
#SBATCH -J 3dpropagation_probeC_more_sampling
#SBATCH --partition=pi_esi
#SBATCH --time 72:00:00
#SBATCH --ntasks=1
#SBATCH --mem-per-cpu=5000

### Load MPI module
#module load MPI/IntelMPI/15.0.2

#make clean 

#make

echo "SLURM_NODELIST $SLURM_NODELIST" 
echo "NUMBER OF CORES $SLURM_NTASKS" 
echo "Running program on $SLURM_CPUS_ON_NODE CPU cores" 

### Run on multiple nodes using mpirun
 
date

mpirun -np 1 ./3dpropagation > out 

date


