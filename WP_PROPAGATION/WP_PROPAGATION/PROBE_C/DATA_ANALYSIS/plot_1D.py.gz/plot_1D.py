###########################################################
###     Read UV-Xray spectra from main program 		###
###            and plot different cuts			###
###########################################################

import os
import numpy as np
from matplotlib import pyplot as plt

au2fs=0.024188843341

###########################################################
### Set input and output file name

#filename='../uv-xray-spectrum.dat'
filename='../expect-uv-xray-spect.dat'

outputfile='1D_plot.pdf'

###########################################################
### Set some parameters

x_min = 280 
x_max = 305
dx = 5

### select points to plot
ntag = []

ntag.append(0)
ntag.append(20)	# approx. 10 fs
ntag.append(40)	# approx. 20 fs
ntag.append(60)	# approx. 30 fs 

###########################################################
### Import data
### Note: the order of the data is: energy, intensity, time

data=np.loadtxt(filename)

###########################################################
### Get number of points for each spectrum and number of times

temp=data[0,2]
nspectrum=0
for i in range(len(data)):
	if(data[i,2]==temp):
		nspectrum+=1

print('\n nspectrum =',nspectrum)

ntimes=int(len(data)/nspectrum)

print('\n ntimes =',ntimes)

###########################################################
### Separate data for plotting

energy=np.zeros(nspectrum)
for i in range(nspectrum):
	energy[i]=data[i,0]

time=np.zeros(ntimes)
icount=0
for i in range(ntimes):
	time[i] = data[i*nspectrum,2]

intens=np.zeros([ntimes,nspectrum])

icount=0
for i in range(ntimes):
	for j in range(nspectrum):
		intens[i,j]=data[icount,1]
		icount+=1

###########################################################
### Chance units

time=time*au2fs

###########################################################
### Normalize spectra

intens=intens/np.max(intens)

###########################################################
### Generate label

label=[]
for i in range(len(ntag)):
	label.append(round(time[ntag[i]],2)) 

###########################################################
### Plot data

plt.rcParams['axes.linewidth'] = 1.5

fig1,ax1= plt.subplots()

#fig1.subplots_adjust(bottom=0.12,right=1.0,top=0.92)

lw=2.

for i in range(len(ntag)):
	ax1.plot(energy,intens[ntag[i],:]+i,lw=lw,label=label[i])  

### set labels

sz = 18
#ax1.set_title('scan',size=sz)

sz = 16
ax1.set_xlabel(r'$\mathregular{\omega \ (eV)}$',size=sz)

ax1.set_ylabel(r'$\mathregular{I \ (arb. u.)}$',size=sz)

### set axis limits

x_axis=[x_min,x_max]
#y_axis=[-180,180]

ax1.set_xlim(x_axis)

#ax1.set_ylim(y_axis)

### set axis ticks

ax1.set_xticks(np.arange(x_min,x_max+dx,dx))

#ax1.set_yticks(np.arange(-180.,180.+45.,45.))

labelsz = 12
ax1.tick_params(axis='both',which='major',labelsize=labelsz)

### set legend

plt.legend(loc=2,frameon=True,framealpha=1.,edgecolor='k')

### plot

plt.show()

###########################################################
### Save plot

fig1.savefig(outputfile,format='pdf',dpi=1200)

###########################################################
### End program

print('\n DONE!! \n')

