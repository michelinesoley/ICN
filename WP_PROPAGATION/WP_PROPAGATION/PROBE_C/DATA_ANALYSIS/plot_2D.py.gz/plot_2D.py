###########################################################
###   Read UV-Xray spectra from main program		###
###          and plot contour plot			###
###########################################################

import numpy as np
from matplotlib import pyplot as plt

au2fs=0.024188843341

###########################################################
### Set input and output file name

filename='../uv-xray-spectrum.dat'
#filename='../expect-uv-xray-spect.dat'

###########################################################
### Set some parameters

itag=1	#if itag=0 plots contour; else plots filled contour

cm_color='seismic' 
cm_color='bwr' 
#cm_color='jet'

x_min = 285
x_max = 305
dx = 5

y_min = 0
y_max = 70
dy = 10

###########################################################
### Import data
### Note: the order of the data is: energy, intensity, time

data=np.loadtxt(filename)

###########################################################
### Get number of points for each spectrum and number of times

temp=data[0,2]
nspectrum=0
for i in range(len(data)):
	if(data[i,2]==temp):
		nspectrum+=1

print('\n nspectrum =',nspectrum)

ntimes=int(len(data)/nspectrum)

print('\n ntimes =',ntimes)

###########################################################
### Separate data for 2D plotting

energy=np.zeros(nspectrum)
for i in range(nspectrum):
	energy[i]=data[i,0]


time=np.zeros(ntimes)
icount=0
for i in range(ntimes):
	time[i] = data[i*nspectrum,2]

intens=np.zeros([ntimes,nspectrum])

icount=0
for i in range(ntimes):
	for j in range(nspectrum):
		intens[i,j]=data[icount,1]
		icount+=1

###########################################################
### Chance units

time=time*au2fs

###########################################################
### Normalize spectra

intens=intens/np.max(intens)

###########################################################
### Plot contour spectra 

plt.rcParams['axes.linewidth'] = 1.5

fig,ax=plt.subplots()

#fig.subplots_adjust(bottom=0.12,right=1.0,top=0.92)

dl=0.1
levels = np.arange(0.,1.+dl,dl)
print('\n levels =',levels)

lw=2.

if(itag==0):
	ax.contour(energy,time,intens,levels,linestyles='solid',linewidths=lw,cmap=cm_color)
else:
	CS  = ax.contourf(energy,time,intens,levels,linestyles='solid',cmap=cm_color)  
	CS1 = ax.contour(CS,levels=CS.levels[::1],colors='k',linewidths=1)

	CB = fig.colorbar(CS)
	CB.add_lines(CS1)

	labelsize = 18
	CB.ax.tick_params(labelsize=labelsize)
	CB.set_ticks(np.arange(0.,1.+.1,.1))

### set labels

#ax.set_title('Time-resolved C X-ray spectra',size=18)

sz = 16
ax.set_xlabel(r'$\mathregular{\omega \ (eV)}$',size=sz)

ax.set_ylabel(r'$\mathregular{Delay \ time \ (fs)}$',size=sz)

### set axis limits

x_axis=[x_min,x_max]
y_axis=[y_min,y_max]

ax.set_xlim(x_axis)

ax.set_ylim(y_axis)

### set axis ticks

ax.set_xticks(np.arange(x_min,x_max+dx,dx))

ax.set_yticks(np.arange(y_min,y_max+dy,dy))

labelsz = 14
ax.tick_params(axis='both',which='major',labelsize=labelsz)

### plot

plt.show()

###########################################################
### Save plot

if (itag==0):
	fig.savefig('2D_plot_contour.pdf',format='pdf',dpi=1200)
else:
	fig.savefig('2D_plot_contourf.pdf',format='pdf',dpi=1200)


###########################################################
### End program

print('\n DONE!! \n')

